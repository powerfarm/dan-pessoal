export class AudioRecorder {
  constructor() {}
}
